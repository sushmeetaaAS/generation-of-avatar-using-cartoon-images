export const SET_AVATAR_OPTION = 'SET_AVATAR_OPTION'
export const UNDO = 'UNDO'
export const REDO = 'REDO'
export const SET_SIDER_STATUS = 'SET_SIDER_STATUS'
